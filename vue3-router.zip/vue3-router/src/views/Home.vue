<template>
    <div>
<h2>欢迎来到我的博客</h2>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>