<template>
  <div class="order">
    <h3>订单信息</h3>
    <p>感谢您的购买！订单已提交。</p>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped>
.order {
  text-align: center;
  margin-top: 20px;
}
</style>
