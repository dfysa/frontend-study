Page({
  data: {
    question: null,
    showEditor: false,
    isEditing: false,
    showOptions: false,
    formattedTime: '',
    mainAnswers: [],
    userId: null, // 当前用户 ID
    isOwner: false,
    editContent: '', // 编辑模式下的内容
    id: null, // 用于存储当前问题的 ID
  },
  
  onLoad(options) {
    // 确保在页面加载时获取到问题 ID 并获取相应的详情
    if (options.id) {
      this.setData({ id: options.id });
      this.fetchQuestionDetail(options.id); // 调用获取问题详情的函数
    }
    this.getUserIdFromToken(); // 获取当前用户ID
  },

  async fetchQuestionDetail(id) {
    try {
      const res = await wx.request({
        url: `https://p991807p39.goho.co/api/v1/questions/${id}`, // 使用传入的ID获取问题详情
        method: 'GET',
        success: (response) => {
          if (response.data.data) {
            const question = response.data.data;
            const formattedTime = this.formatTime(question.createTime); // 格式化时间
            const mainAnswers = question.answers.filter(a => a.parentId === null); // 获取主回答
            this.setData({ 
              question, 
              formattedTime, 
              mainAnswers, 
              isOwner: this.data.userId === question.userId // 判断是否是当前用户的问题
            });
          }
        },
        fail: (error) => {
          console.error("获取问题详情失败:", error);
        },
      });
    } catch (error) {
      console.error('请求失败:', error);
    }
  },

  formatTime(time) {
    const now = new Date();
    const postTime = new Date(time);
    const diff = Math.floor((now - postTime) / 1000);
    if (diff < 60) return '刚刚发布';
    else if (diff < 3600) return `${Math.floor(diff / 60)}分钟前`;
    else if (diff < 86400) return `${Math.floor(diff / 3600)}小时前`;
    return `${Math.floor(diff / 86400)}天前`;
  },

  getUserIdFromToken() {
    const token = wx.getStorageSync('token');
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      this.setData({ userId: payload.id });
    }
  },

  toggleEditor() {
    this.setData({ showEditor: !this.data.showEditor });
  },

  submitAnswer(event) {
    const content = event.detail.value;
    const { question } = this.data;
    wx.request({
      url: `https://p991807p39.goho.co/api/v1/answers/add`,
      method: 'POST',
      data: {
        content,
        relatedQuestionId: question.id,
      },
      success: () => {
        this.setData({ showEditor: false });
        this.fetchQuestionDetail(question.id); // 刷新问题详情
      },
      fail: (error) => {
        console.error("提交答案失败:", error);
      },
    });
  },

  toggleLike() {
    const { question } = this.data;
    wx.request({
      url: `https://p991807p39.goho.co/api/v1/likes/toggle`,
      method: 'POST',
      data: { targetId: question.id, type: 2 },
      success: () => {
        this.fetchQuestionDetail(question.id); // 刷新点赞信息
      },
      fail: (error) => {
        console.error("点赞失败:", error);
      },
    });
  },

  toggleOptions() {
    this.setData({ showOptions: !this.data.showOptions });
  },

  editQuestion() {
    this.setData({
      isEditing: true,
      editContent: this.data.question.content,
    });
  },

  handleInput(event) {
    this.setData({ editContent: event.detail.value });
  },

  submitEdit() {
    const { question, editContent } = this.data;
    wx.request({
      url: `https://p991807p39.goho.co/api/v1/questions/edit/${question.id}`,
      method: 'PUT',
      data: {
        content: editContent,
        title: question.title,
      },
      success: () => {
        this.setData({ isEditing: false });
        this.fetchQuestionDetail(question.id); // 刷新问题详情
      },
      fail: (error) => {
        console.error("编辑问题失败:", error);
      },
    });
  },

  cancelEdit() {
    this.setData({ isEditing: false });
  },

  deleteQuestion() {
    const { question } = this.data;
    wx.request({
      url: `https://p991807p39.goho.co/api/v1/questions/delete/${question.id}`,
      method: 'PUT',
      success: () => {
        wx.navigateBack(); // 删除成功后返回上一个页面
      },
      fail: (error) => {
        console.error("删除问题失败:", error);
      },
    });
  },
});
